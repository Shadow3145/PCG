BECOME A GREAT ARTIST IN JUST 10 SECONDS
With Andi and Michael

On Mac double click:
artist_mac

On Windows double click:
artist_windows

Made by 

Michael Brough 
smestorp@gmail.com
http://smestorp.com

and 

Andi McClure
andi.m.mcclure@gmail.com
http://runhello.com

Incorporating music by Ivy Baumgarten
For Ludum Dare 27
Version 1.1

If it didn't work (OR YOU WANT TO SEND US YOUR ART!) email us

See https://bitbucket.org/runhello/ufo
for source code and additional license information.
