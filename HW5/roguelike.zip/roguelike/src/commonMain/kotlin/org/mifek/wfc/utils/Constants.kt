package org.mifek.wfc.utils

/**
 * We use log base of 2
 */
const val LOG_BASE = 2.0 // Math.E