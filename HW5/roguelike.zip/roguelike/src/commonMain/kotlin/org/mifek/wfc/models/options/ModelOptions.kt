package org.mifek.wfc.models.options

interface ModelOptions {
    val allowRotations: Boolean
    val periodicOutput: Boolean
    val periodicInput: Boolean
}
