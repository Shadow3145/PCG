package cz.cuni.gamedev.nail123.roguelike.world.worlds;

import java.util.*;


import cz.cuni.gamedev.nail123.roguelike.entities.enemies.Rat;
import cz.cuni.gamedev.nail123.roguelike.mechanics.Pathfinding;
import cz.cuni.gamedev.nail123.roguelike.world.IArea;
import cz.cuni.gamedev.nail123.utils.collections.ObservableMap;
import cz.cuni.gamedev.nail123.roguelike.entities.objects.Stairs;
import cz.cuni.gamedev.nail123.roguelike.events.LoggedEvent;
import cz.cuni.gamedev.nail123.roguelike.world.Area;
import cz.cuni.gamedev.nail123.roguelike.world.World;
import cz.cuni.gamedev.nail123.roguelike.blocks.*;
import cz.cuni.gamedev.nail123.roguelike.world.builders.AreaBuilder;
import cz.cuni.gamedev.nail123.roguelike.world.builders.EmptyAreaBuilder;
import org.hexworks.zircon.api.data.*;
import org.jetbrains.annotations.NotNull;

public class SampleJavaWorld extends World {
    int currentLevel = 0;
    final double MIN = 6.5;
    final double MAX = 4.5;
    int mapWidth;
    int mapHeight;
    boolean change = true;
    public Random rand;

    class Room {
        public Position3D topCorner;
        public Position3D bottomCorner;

        public Room(Position3D topCorner, Position3D bottomCorner) {
            this.topCorner = topCorner;
            this.bottomCorner = bottomCorner;
        }

        public int minX() { return topCorner.getX(); }

        public int maxX() { return bottomCorner.getX(); }

        public int minY() { return topCorner.getY(); }

        public int maxY() { return bottomCorner.getY(); }

        public int getWidth() { return maxX() - minX(); }

        public int getHeight() { return maxY() - minY(); }
    }

    enum Side {
        LEFT,
        TOP,
        RIGHT,
        DOWN
    }

    class Edge {
        public Node node1;
        public Node node2;
        Side side;

        public Edge (Node node1, Node node2, Side side) {
            this.node1 = node1;
            this.node2 = node2;
            this.side = side;
        }
    }


    class Node {
        public Room room;
        public Map<Node, Side> neighbours;
        public boolean used;

        public Node(Room room, Map<Node, Side> neighbours) {
            this.room = room;
            this.neighbours = neighbours;
            this.used = false;
        }
    }
    public SampleJavaWorld() {
    }

    @NotNull
    @Override
    public Area buildStartingArea() {
        return buildLevel();
    }

    Area buildLevel() {
        // Initialization
        rand = new Random();

        // Start with an empty area
        AreaBuilder areaBuilder = (new EmptyAreaBuilder()).create();

        mapWidth = areaBuilder.getWidth();
        mapHeight = areaBuilder.getHeight();
        var map = areaBuilder.getBlocks();

        // Put walls everywhere
        for (int i = 0; i < mapWidth; i++) {
            for (int j = 0; j < mapHeight; j++)
                map.put(Position3D.create(i, j, 0), new Wall());
        }

        List<Node> rooms = new ArrayList<>();

        Room startRoom = new Room(Position3D.create(0, 0, 0),
                Position3D.create(mapWidth-1, mapHeight-1, 0));

        Node startNode = new Node(startRoom, new HashMap<>());

        rooms.add(startNode);

        // Split rooms
        do {
            change = false;
            rooms = splitter(rooms);
        } while (change || rooms.size() <= 5 );

        // Find neighbours
        for (Node node : rooms)
            findNeighbours(node, rooms);

        // Shrink rooms
        for (Node node : rooms) {
            shrinkRoom(node);
        }

        // Draw rooms and remove invalid neighbours
        for (Node node : rooms) {
            drawRoom(node.room, map);
            removeNeighbours(node);
        }

        // Find spanning tree and draw corridors between the rooms
        List<Edge> spanningTree = findSpanningTree(rooms);
        for (Edge edge : spanningTree) {
            edge.node1.used = false;
            edge.node2.used = false;
            if (edge.side == Side.RIGHT || edge.side == Side.LEFT)
                drawHorizontalCorridor(edge, map);
            else
                drawVerticalCorridor(edge, map);
        }

        // Place the player at an empty location in the room at the top corner
        areaBuilder.addAtEmptyPosition(
                areaBuilder.getPlayer(),
                Position3D.create(1, 1, 0),
                Size3D.create(1, 1, 1)
        );

        // Place the stairs at an empty location far away from the player
        Room stairs = placeStairs(rooms);
        areaBuilder.addAtEmptyPosition(
                new Stairs(),
                Position3D.create(stairs.maxX() - 1, stairs.maxY() -1, 0),
                Size3D.create(1, 1, 1)
        );

        // Place rats in the room with the stairs
        for (int i = 0; i <= currentLevel; ++i) {
            areaBuilder.addAtEmptyPosition(
                    new Rat(),
                    Position3D.create(stairs.minX() + 1, stairs.minY() +  1, 0),
                    Size3D.create(stairs.getWidth() - 2, stairs.getHeight() -2, 1));
        }

        // Build it into a full Area
        return areaBuilder.build();
    }

    public List<Node> splitter(List<Node> rooms) {
        List<Node> newRooms = new ArrayList<>();
        for (var r : rooms) {
            splitArea(r, newRooms);
        }
        return newRooms;
    }

    public void splitArea(Node node, List<Node> rooms) {
        // The split axis is chosen randomly
        float axis = rand.nextFloat();
        // Below 50 % is x axis, above is y axis
        if (axis < 0.5) {
            // if the rooms is too small, don't split it
            if ((float) node.room.getWidth()/2 < mapWidth/MIN) {
                rooms.add(node);
                return;
            }
            // if the rooms is big we might split it 1 : 2
            if ((float) node.room.getWidth()/2 >= mapWidth/MAX) {
                float f = rand.nextFloat();
                if (f <= (1 - (float)(mapWidth/MAX)/((float)node.room.getWidth()/2))) {
                    splitX(node, rooms, 3);
                    return;
                }
            }

            // if the rooms is not too big, we might not split it
            if ((float) node.room.getWidth()/2 < mapWidth/MAX) {
                float f = rand.nextFloat();
                if (f <= (float) (mapWidth/MIN)/((float) node.room.getWidth()/2)) {
                    rooms.add(node);
                    return;
                }
            }
            splitX(node, rooms, 2);
            return;
        }

        // Splitting by y axis, nearly identical to splitting by y axis
        if ((float) node.room.getHeight()/2 < mapHeight/MIN) {
            rooms.add(node);
            return;
        }
        if ((float) node.room.getHeight()/2 >= mapHeight/MAX) {
            float f = rand.nextFloat();
            if (f <= (1 - (float) (mapHeight/MAX)/((float) node.room.getHeight()/2))) {
                splitY(node, rooms, 3);
                return;
            }
        }

        if ((float) node.room.getHeight()/2 < mapHeight/MAX) {
            float f = rand.nextFloat();
            if (f <= (float) (mapHeight/MIN)/((float) node.room.getHeight()/2)) {
                rooms.add(node);
                return;
            }
        }

        splitY(node, rooms, 2);
    }

    public void splitX(Node node, List<Node> rooms, int div) {
        Room room1 = new Room(node.room.topCorner,
                Position3D.create(node.room.getWidth() / div + node.room.minX(), node.room.maxY(), 0));
        Room room2 = new Room(Position3D.create(node.room.getWidth() / div + node.room.minX(),
                node.room.minY(), 0), node.room.bottomCorner);
        Node node1 = new Node(room1, new HashMap<>());
        Node node2 = new Node(room2, new HashMap<>());

        rooms.add(node1);
        rooms.add(node2);
        rooms.remove(node);
        change = true;
    }

    public void splitY(Node node, List<Node> rooms, int div) {
        Room room1 = new Room(node.room.topCorner, Position3D.create(node.room.maxX(), node.room.getHeight() / div + node.room.minY(), 0));
        Room room2 = new Room(Position3D.create(node.room.minX(), node.room.getHeight() / div + node.room.minY(), 0), node.room.bottomCorner);

        Node node1 = new Node(room1, new HashMap<>());
        Node node2 = new Node(room2, new HashMap<>());

        rooms.add(node1);
        rooms.add(node2);
        rooms.remove(node);
        change = true;
    }

    public void findNeighbours(Node node, List<Node> rooms) {
        // For each room we go through the rest of the rooms and check whether they share and edge. If yes, they are neighbours
        for (Node n : rooms) {
            if (n.room.topCorner == node.room.topCorner)
                continue;
            if (node.room.maxX() == n.room.minX()) {
                node.neighbours.put(n, Side.RIGHT);
                n.neighbours.put(node, Side.LEFT);
                continue;
            }
            if (node.room.minX() == n.room.maxX()) {
                node.neighbours.put(n, Side.LEFT);
                n.neighbours.put(node, Side.RIGHT);
                continue;
            }
            if (node.room.minY() == n.room.maxY()) {
                node.neighbours.put(n, Side.TOP);
                n.neighbours.put(node, Side.DOWN);
                continue;
            }
            if (node.room.maxY() == n.room.minY()) {
                node.neighbours.put(n, Side.DOWN);
                n.neighbours.put(node, Side.TOP);
            }
        }
    }

    public void removeNeighbours(Node node) {
        // After shrinking some rooms might not be on the same level anymore so they can't be connected directly.
        // Such rooms are not neighbours.
        Map<Node, Side> newNeighbours = new HashMap<>(node.neighbours);
        for (Node n : node.neighbours.keySet()) {
            Side side = node.neighbours.get(n);
            if (side == Side.LEFT || side == Side.RIGHT) {
                if (n.room.minY() >= node.room.maxY()  || n.room.maxY() <= node.room.minY()) {
                    newNeighbours.remove(n);
                    n.neighbours.remove(node);
                }
                continue;
            }
            if (n.room.minX() >= node.room.maxX() + 1 || n.room.maxX() <= node.room.minX()) {
                newNeighbours.remove(n);
                n.neighbours.remove(node);
            }

        }
        node.neighbours = newNeighbours;
    }

    public void shrinkRoom(Node node) {
        // The rooms are shrank to 70 % - 100 % of their original size.
        float w =  Math.min((float)rand.nextInt(350)/1000 + 0.7f, 1.0f);
        float h =  Math.min((float)rand.nextInt(350)/1000 + 0.7f, 1.0f);
        int width = (int) Math.floor(node.room.getWidth() * w);
        int height = (int) Math.floor(node.room.getHeight() * h);
        Position3D top = node.room.topCorner;

        int botX = top.getX() + width;
        int botY = top.getY() + height;
        if (botX >= mapWidth)
            botX = mapWidth - 1;
        if (botY >= mapHeight)
            botY = mapHeight - 1;
        //System.out.println("NEW ROOM: " + top + " botX: " + botX + " botY: " + botY);
        node.room = new Room(top, Position3D.create(botX, botY, 0));
    }

    public void drawRoom(Room room, ObservableMap<Position3D, GameBlock> map) {
        for (int i = room.minX() + 1 ; i < room.maxX(); i++) {
            for (int j = room.minY() + 1; j < room.maxY(); j++)
                map.put(Position3D.create(i, j, 0), new Floor());
        }
    }

    public List<Edge> findSpanningTree(List<Node> rooms) {
        List<Edge> tree = new ArrayList<>();

        for (Node node : rooms) {
            if (!node.used)
                visit(node, tree, rooms);
        }
        return tree;
    }

    public void visit(Node node, List<Edge> tree, List<Node> rooms) {
        node.used = true;
        for (Node neighbour : node.neighbours.keySet()) {
            if (neighbour.used)
                continue;
            tree.add(new Edge(node, neighbour, node.neighbours.get(neighbour)));
            visit(neighbour, tree, rooms);
        }
    }

    public void drawHorizontalCorridor(Edge edge, ObservableMap<Position3D, GameBlock> map) {
        int doorY;
        // The door should be in the middle of the area where the two rooms share the same y coordinate
        if (edge.node1.room.minY() > edge.node2.room.minY())
            doorY = (edge.node1.room.minY() + Math.min(edge.node2.room.maxY(), edge.node1.room.maxY()))/2;
        else
            doorY = (Math.min(edge.node1.room.maxY(), edge.node2.room.maxY()) + edge.node2.room.minY())/2;

        int doorLeft;
        int doorRight;

        int temp;
        if (edge.side == Side.RIGHT) {
            temp = edge.node1.room.maxX();
            doorRight = edge.node2.room.minX();
        }
        else {
            temp = edge.node1.room.minX();
            doorRight = edge.node2.room.maxX();
        }
        doorLeft = Math.min(temp, doorRight);
        doorRight = Math.max(temp, doorRight);

        // Doors
        map.put(Position3D.create(doorLeft, doorY, 0), new Floor());
        map.put(Position3D.create(doorRight, doorY, 0), new Floor());

        // Corridor
        for (int x = doorLeft - 1; x <= doorRight + 1; x++) {
            map.put(Position3D.create(x, doorY, 0), new Floor());
        }
    }

    public void drawVerticalCorridor(Edge edge, ObservableMap<Position3D, GameBlock> map) {
        // The door should be in the middle of the area where the two rooms share the same x coordinate
        int doorX;
        if (edge.node1.room.minX() > edge.node2.room.minX()) {
            doorX = (edge.node1.room.minX() + Math.min(edge.node1.room.maxX(), edge.node2.room.maxX()))/2;
        }
        else
            doorX = (Math.min(edge.node1.room.maxX(), edge.node2.room.maxX()) + edge.node2.room.minX())/2;

        int doorTop;
        int doorBot;

        int temp;
        if (edge.side == Side.DOWN) {
            temp = edge.node1.room.maxY();
            doorBot = edge.node2.room.minY();
        }
        else {
            temp = edge.node1.room.minY();
            doorBot = edge.node2.room.maxY();
        }
        doorTop = Math.min(temp, doorBot);
        doorBot = Math.max(temp, doorBot);

        // Door
        map.put(Position3D.create(doorX, doorTop, 0), new Floor());
        map.put(Position3D.create(doorX, doorBot, 0), new Floor());

        // Corridor
        for (int y = doorTop - 1; y <= doorBot + 1; y++) {
            map.put(Position3D.create(doorX, y, 0), new Floor());
        }
    }

    public Room placeStairs(List<Node> nodes) {
        int maxX = 0;
        int maxY = 0;
        Room stairs = null;
        for (Node node : nodes) {
            if (node.room.maxX() + node.room.maxY() > maxX + maxY)
            {
                maxX = node.room.maxX();
                maxY = node.room.maxY();
                stairs = node.room;
            }
        }

        return stairs;
    }

    /**
     * Moving down - goes to a brand new level.
     */
    @Override
    public void moveDown() {
        ++currentLevel;
        (new LoggedEvent(this, "Descended to level " + (currentLevel + 1))).emit();
        if (currentLevel >= getAreas().getSize()) getAreas().add(buildLevel());
        goToArea(getAreas().get(currentLevel));
    }

    /**
     * Moving up would be for revisiting past levels, we do not need that. Check [DungeonWorld] for an implementation.
     */
    @Override
    public void moveUp() {
        // Not implemented
    }
}
