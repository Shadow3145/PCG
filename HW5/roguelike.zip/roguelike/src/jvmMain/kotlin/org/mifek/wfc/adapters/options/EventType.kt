package org.mifek.wfc.adapters.options

enum class EventType {
    BAN,
    PROPAGATION_STEP,
    OBSERVATION,
    STEP,
}