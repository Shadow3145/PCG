package cz.cuni.gamedev.nail123.roguelike.events

import cz.cuni.gamedev.nail123.roguelike.Game

class GameStep(override val emitter: Game): GameEvent()