package cz.cuni.gamedev.nail123.roguelike.events

class GameOver(override val emitter: Any): GameEvent()