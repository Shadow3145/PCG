package cz.cuni.gamedev.nail123.roguelike.entities.attributes

interface HasSmell {
    val smellingRadius: Int
}