package cz.cuni.gamedev.nail123.roguelike.entities.attributes

interface HasVision {
    val visionRadius: Int
}