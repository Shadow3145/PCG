package cz.cuni.gamedev.nail123.roguelike.entities

enum class SortingLayer {
    ITEM, STAIRS, CHARACTER
}